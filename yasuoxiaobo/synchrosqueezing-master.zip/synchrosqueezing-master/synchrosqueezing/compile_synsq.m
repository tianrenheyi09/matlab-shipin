% Compile MEX files for Synchrosqueezing toolbox (deprecated)
%
%---------------------------------------------------------------------------------
%    Synchrosqueezing Toolbox
%    Authors: Eugene Brevdo (http://www.math.princeton.edu/~ebrevdo/)
%---------------------------------------------------------------------------------
mex curve_ext.c
mex synsq_cwt_squeeze_mex.c
mex diff_mex.c
